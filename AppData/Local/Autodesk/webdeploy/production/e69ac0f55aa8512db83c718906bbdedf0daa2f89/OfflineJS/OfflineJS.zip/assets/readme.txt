For information on where files should go in this directory structure, go to this link:

https://github.com/ngbp/ngbp/blob/v0.3.1-release/src/README.md

Ken