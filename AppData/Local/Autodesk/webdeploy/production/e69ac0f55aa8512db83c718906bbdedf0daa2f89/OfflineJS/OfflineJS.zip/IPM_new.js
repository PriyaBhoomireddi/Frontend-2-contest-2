IPM = {
	bootStrap: function () {
		//debugger;
		var target = this;
		if (!jQuery) {
			setTimeout(
				function () {
					target.bootStrap();
				}
				, 10);
			return;
		}
		console.log("bootStrap");
		//not all browsers support origin property, so need fix it by a combined url in this case.
		if (window.location.origin == undefined)
			window.location.origin = window.location.protocol + "//" + window.location.host;

		var server = window.location.host;
		console.log(server);
		var scripts = document.getElementsByTagName('script');

		jQuery.each(scripts, function (key, value) {
			if (this.src.indexOf('IPM_new.js') != -1) {
				server = this.src;
				var index = server.indexOf('/IPM_new.js');
				server = server.substr(0, index);
			}
		});

		console.log(server);
		target.showIPMOptions(server);
	},

	showIPMOptions: function (server) {
		console.log("showIPMOptions");

		if (typeof neu === 'undefined')
			neu = {};

		if (typeof neu.utils === 'undefined') {
			neu.utils = {};

			neu.utils.resourceManager = {};

			neu.utils.resourceManager.loadResource = function (resFiles, callback) {
				var language = '';

				if (typeof resFile == 'string')
					resFiles = [resFile];

				// For testing purpose, use Neutron user language. Ideally we should use the language on Qontext page
				//
				if (window.neutronJavaScriptObject)
					window.neutronJavaScriptObject.executeQuery('GetUserLanguage', '', function (response) { 
						language = response;
					});
			};
		}
		var self = this;

		window.neutronJavaScriptObject.executeQuery('getLocStrings2', '', function (locStrings) {
			//console.log(locStrings);
			if (locStrings) {
				neu.locStrings = JSON.parse(locStrings);
			}

			if (!neu || !neu.locStrings) {
				setTimeout(function () { self.showIPMOptions(server); }
					, 10);
				return;
			}
			var application = 
				{
					appId: 'Fusion360',
					descriptionTrialExpiring: neu.locStrings.fusionTrialAboutToExpire,
					descriptionTrialEntitlemet: neu.locStrings.fusionTrialEntitlementDescription,
					descriptionEntitlemet: neu.locStrings.fusionEntitlementDescription,
					descriptionExpired: neu.locStrings.fusionExpired,
					banner: server + '/myimages/Fusion360_purchase_banner.png',
					closeIcon: server + '/myimages/close.png',
					closeButton: neu.locStrings.trialCloseAction,
					btncontinue: neu.locStrings.btncontinue,
					btnBuyNow: neu.locStrings.btnBuyNow,
					qualifyForFreeUse: neu.locStrings.qualifyForFreeUse,
					allSetBanner: server + '/myimages/all_set.png'
				};

			// This is kinda wonky, but we need the url of an image dynamically in css
			var dynamicStyle = document.createElement('style');
			var adjustedServer = server.replace('file:///', '');
			dynamicStyle.type = 'text/css';
			dynamicStyle.innerHTML = '.use-btn { background-image: url("' + adjustedServer + '/myimages/caret-right-16.svg"); }';
			document.getElementsByTagName('head')[0].appendChild(dynamicStyle);
			var now = new Date();
			var args = {};
			if (!application)
				return;
			args.appId = application.appId;
			window.neutronJavaScriptObject.executeQuery('EntitlementDetails', JSON.stringify(args), function (retEntitlement) {
				var entitlement = JSON.parse(retEntitlement);
				var item = {};
				item.appId = application.appId;
				item.banner = application.banner;
				item.closeIcon = server + '/myimages/close.png';
				item.closeButton = neu.locStrings.trialCloseAction;

				item.btncontinue = application.btncontinue;

				item.btnBuyNow = application.btnBuyNow;
				item.qualifyForFreeUse = application.qualifyForFreeUse;
				item.contactForHelp = neu.locStrings.contactForHelp;
				item.hrefContactForHelp = neu.locStrings.hrefContactForHelp;

				item.link = neu.locStrings.fusionPurchaseLink;

				item.startupTipInfo = neu.locStrings.startupTipInfo;
				item.startupLink = neu.locStrings.startupLink;
				item.validateStartupInfoUpdated = neu.locStrings.validateStartupInfoUpdated;

				item.useFusionSolelyAs = neu.locStrings.useFusionSolelyAs;
				item.personalProjects = neu.locStrings.personalProjects;
				item.startupCompany = neu.locStrings.startupCompany;
				item.startupCompanyTerms = neu.locStrings.startupCompanyTerms;
				item.eduStudent = neu.locStrings.eduStudent;
				item.directbuynow = neu.locStrings.directbuynow;
				item.readmoreLicenseInfo = neu.locStrings.readmoreLicenseInfo;
				item.hrefReadLicense = neu.locStrings.hrefReadLicense;
				item.btnDirectBuyNow = neu.locStrings.btnDirectBuyNow;
				item.fusionRegEduLink = neu.locStrings.fusionRegEduLink;

				item.oneMoreStep = neu.locStrings.oneMoreStep;
				item.personalPlanUseFusion = neu.locStrings.personalPlanUseFusion;
				item.licenseCertityInfo = neu.locStrings.licenseCertityInfo;
				item.personalCheckOneDescribe = neu.locStrings.personalCheckOneDescribe;
				item.personalCheckTwoDescribe = neu.locStrings.personalCheckTwoDescribe;
				item.personalConfirmStatement = neu.locStrings.personalConfirmStatement;
				item.hrefPricingOptions = neu.locStrings.fusionPurchaseLink;
				item.personalCompleteRegistration = neu.locStrings.personalCompleteRegistration;
				item.personalBuyNow = neu.locStrings.personalBuyNow;
				item.returnBack = neu.locStrings.returnBack;

				item.startupPlanUseFusion = neu.locStrings.startupPlanUseFusion;
				item.startupCompanyInfo = neu.locStrings.startupCompanyInfo;
				item.startupWebsiteInfo = neu.locStrings.startupWebsiteInfo;
				item.startupCertityInfo = neu.locStrings.startupCertityInfo;
				item.startupCheckOneDescribe = neu.locStrings.startupCheckOneDescribe;
				item.startupCompanyEmptyErr = neu.locStrings.startupCompanyEmptyErr;
				item.startupwebsiteEmptyErr = neu.locStrings.startupwebsiteEmptyErr;

				item.allSetBanner = application.allSetBanner;
				item.accountAllSetInfo = neu.locStrings.accountAllSetInfo;
				item.startupWaitDetail = neu.locStrings.startupWaitDetail;
				item.accountThanksInfo = neu.locStrings.accountThanksInfo;
				item.accountAllSetDetail = neu.locStrings.accountAllSetDetail;
				item.startupAllSetDetail = neu.locStrings.startupAllSetDetail;
				item.startUsingFusion = neu.locStrings.startUsingFusion;
				item.gotIt = neu.locStrings.gotIt;

				item.purchaseCartPic = server + '/myimages/cart.png';
				item.eduRegCartPic = server + '/myimages/education.png';
				item.validateWaitBanner = server + '/myimages/spinner.gif';
				item.notFoundBanner = server + '/myimages/warning.png';
				item.copyButtonImg = server + '/myimages/CopyToClipboard.png';
				item.processingBanner = server + '/myimages/processingarrow.png';
				item.helpBuyLink = 'https://help.autodesk.com/view/STORE/ENU';
				item.helpLink = 'https://help.autodesk.com/view/fusion360/ENU/?page=support';

				item.languageCode = neu.locStrings.languageCode;

				item.expiryDescription = '';
				if (entitlement.isnull === false) {
					item.trial = (entitlement.trial === true);
					if (item.trial) {
						if (entitlement.expiring) {
							// the expiry date should be in ISO-8601 and therefore correctly be parsed as UTC
							var expiry = new Date(entitlement.expires || '');
							var days = -1;
							if (!isNaN(expiry.getTime()))
								days = (expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
							if (days >= 0)
								days = Math.floor(days + 0.5);
							item.expiryDescription = application.descriptionTrialEntitlemet.replace(/\{0\}/g, days);
						}
					} else if (entitlement.entitled === false) {
						item.expiryDescription = application.descriptionExpired;
						item.icon = server + '/myimages/expired.png';
						item.expired = true;
					}
				}
				else {
					item.expiryDescription = application.descriptionExpired;
					item.icon = server + '/myimages/expired.png';
					item.expired = true;
				}
				var customerTypes = [];
				item.customerTypes = customerTypes;
				
				var target = self;
				// jQuery.getScript(server + '/TryToBuy/myscripts/trialexpiryview.js', function (data, textStatus, jqxhr) {
				jQuery('#banner').attr('src', item.banner);
				jQuery('#closeIcon').attr('src', item.closeIcon);
				jQuery('#closeButton').text(item.closeButton);
				// for BuyFusionNow
				jQuery('#expiryBuyDescription').html(item.expiryDescription);
				jQuery('#btnBuyNow_0').val(item.btnBuyNow);
				jQuery('#contactForHelp').html(item.contactForHelp);
				jQuery('#qualifyForFreeUse').html(item.qualifyForFreeUse);
				// for FreeUseOptoins
				jQuery('#freeUseOptionDescription').html(item.expiryDescription);
				jQuery('#useFusionSolelyAs').html(item.useFusionSolelyAs);
				jQuery('#startupCompanyLbl').html(item.startupCompany);
				jQuery('#personalProjectsLbl').html(item.personalProjects);
				jQuery('#eduStudentLbl').html(item.eduStudent);
				jQuery('#btnDirectBuyNow_0').val(item.btnDirectBuyNow);
				jQuery('#readmoreLicenseInfo').html(item.readmoreLicenseInfo);
				//jQuery('#hrefReadLicense').attr('href',item.hrefReadLicense);
				// for FreePersonalLicense
				jQuery('#personalOneMoreStep').html(item.oneMoreStep);
				jQuery('#personalPlanUseFusion').html(item.personalPlanUseFusion);
				jQuery('#licenseCertityInfo').html(item.licenseCertityInfo);
				jQuery('#licenseCertityInfoComplete').html(item.licenseCertityInfo);
				jQuery('#personalCheckOneDescribe').html(item.personalCheckOneDescribe);
				jQuery('#personalCheckTwoDescribe').html(item.personalCheckTwoDescribe);
				jQuery('#personalConfirmStatement').html(item.personalConfirmStatement);
				jQuery('#personalLicenseContinue').val(item.btncontinue);
				jQuery('#personalCompleteRegistration').val(item.personalCompleteRegistration);
				jQuery('#btnPersonalBuyNow').val(item.personalBuyNow);
				jQuery('#btnPersonalBuyNowComplete').val(item.personalBuyNow);
				jQuery('#personlReadLicenseInfo').html(item.readmoreLicenseInfo);
				jQuery('#personlReadLicenseInfoComplete').html(item.readmoreLicenseInfo);
				jQuery('#personalReturnBack').html(item.returnBack);
				jQuery('#personalReturnBackComplete').html(item.returnBack);
				jQuery('#personalWaitBanner').attr('src', item.validateWaitBanner);
				jQuery('#validatePersonalInfo').html(neu.locStrings.validatePersonalInfo);
				// for FreePersonalTryAgain
				jQuery('#personalTryBanner').attr('src', item.notFoundBanner);
				jQuery('#notFoundInfoPersonal').html(neu.locStrings.notFoundInfoPersonal);
				jQuery('#btnTryItAgainPersonal').val(neu.locStrings.tryItAgain);
				jQuery('#notFoundBackPersonal').html(neu.locStrings.returnBack);

				jQuery('#startupTipInfo').html(neu.locStrings.startupTipInfo);
				jQuery('#finishedStartup').html(neu.locStrings.finishedPurchase);
				jQuery('#finishedStartupContinue').html(neu.locStrings.btncontinue);
				jQuery('#browserNotOpenStartup').html(neu.locStrings.browserNotOpen);
				jQuery('#browserUrlCopyStartupDes').html(neu.locStrings.browserUrlCopyDes);
				jQuery('#browserUrlCopyStartup').val(neu.locStrings.startupLink);
				jQuery('#copyButtonImgStartup').attr('src', item.copyButtonImg);
				jQuery('#startupProcessBack').html(neu.locStrings.returnBack);
				jQuery('#startupCartPic').attr('src', item.purchaseCartPic);
				jQuery('#validateStartupInfo').html(neu.locStrings.validateStartupInfoUpdated);
				jQuery('#validateWaitBannerStartup').attr('src', item.validateWaitBanner);

				jQuery('#notFoundBannerStartup').attr('src', item.processingBanner);
				jQuery('#notFoundInfoStartup').html(neu.locStrings.notFoundInfoEdu);
				jQuery('#processingCommentsStartup').html(neu.locStrings.processingComments);
				jQuery('#btnTryItAgainStartup').val(neu.locStrings.tryItAgain);
				jQuery('#processingTipsStartup').html(neu.locStrings.processingTips);
				jQuery('#getHelpHereStartup').html(neu.locStrings.getHelpHere);
				jQuery('#notFoundBackStartup').html(neu.locStrings.returnBack);

				// for EduRegProcessing
				jQuery('#eduRegTipInfo').html(neu.locStrings.eduRegTipInfo);
				jQuery('#finishedEduReg').html(neu.locStrings.finishedPurchase);
				jQuery('#finishedEduContinue').html(neu.locStrings.btncontinue);
				jQuery('#browserNotOpenEdu').html(neu.locStrings.browserNotOpen);
				jQuery('#browserUrlCopyEduDes').html(neu.locStrings.browserUrlCopyDes);
				jQuery('#browserUrlCopyEdu').val(neu.locStrings.fusionRegEduLink);
				jQuery('#copyButtonImgEdu').attr('src', item.copyButtonImg);
				jQuery('#eduRegProcessBack').html(neu.locStrings.returnBack);
				jQuery('#eduRegCartPic').attr('src', item.eduRegCartPic);
				jQuery('#validateEduInfo').html(neu.locStrings.validateEduInfo);
				jQuery('#validateWaitBannerEdu').attr('src', item.validateWaitBanner);

				jQuery('#notFoundBannerEdu').attr('src', item.processingBanner);
				jQuery('#notFoundInfoEdu').html(neu.locStrings.notFoundInfoEdu);
				jQuery('#processingCommentsEdu').html(neu.locStrings.processingComments);
				jQuery('#btnTryItAgainEdu').val(neu.locStrings.tryItAgain);
				jQuery('#processingTipsEdu').html(neu.locStrings.processingTips);
				jQuery('#getHelpHereEdu').html(neu.locStrings.getHelpHere);
				jQuery('#notFoundBackEdu').html(neu.locStrings.returnBack);

				// PurchaseProcessing
				jQuery('#purchaseTipInfo').html(neu.locStrings.purchaseTipInfo);
				jQuery('#finishedPurchase').html(neu.locStrings.finishedPurchase);
				jQuery('#finishedBuyContinue').html(neu.locStrings.btncontinue);
				jQuery('#purchaseCartPic').attr('src', item.purchaseCartPic);
				jQuery('#browserNotOpen').html(neu.locStrings.browserNotOpen);
				jQuery('#browserUrlCopyDes').html(neu.locStrings.browserUrlCopyDes);
				jQuery('#browserUrlCopy').val(neu.locStrings.fusionPurchaseLink);
				jQuery('#copyButtonImg').attr('src', item.copyButtonImg);
				jQuery('#purchaseProcessBack').html(neu.locStrings.returnBack);
				jQuery('#validateBuyInfo').html(neu.locStrings.validateBuyInfo);
				jQuery('#validateWaitBanner').attr('src', item.validateWaitBanner);

				jQuery('#processingBanner').attr('src', item.processingBanner);
				jQuery('#processingInfo').html(neu.locStrings.processingInfo);
				jQuery('#processingComments').html(neu.locStrings.processingComments);
				jQuery('#btnTryItAgain').val(neu.locStrings.tryItAgain);
				jQuery('#processingTips').html(neu.locStrings.processingTips);
				jQuery('#getHelpHere').html(neu.locStrings.getHelpHere);
				jQuery('#buyProcessingBack').html(neu.locStrings.returnBack);
				// for YouAreAllSet
				jQuery('#allSetBanner').attr('src', item.allSetBanner);
				jQuery('#accountAllSetInfo').html(item.accountAllSetInfo);
				jQuery('#accountAllSetDetail').html(item.accountAllSetDetail);
				jQuery('#btnStartUsingFusion_0').val(item.startUsingFusion);

				var context = {};  // runtime config context varialble
				context.licenseStatus = '';
				context.selectedOption = '';
				context.companyName = '';
				context.websiteName = '';
				context.returnFlag = '';

				var userAgent = window.navigator.userAgent.toLowerCase();
				var isLanguageSettingDone = false;
				console.log("the language code is " + item.languageCode);
				var doLanguageSpecificSetting = function () {
					// if (item.languageCode === 'ja-JP') {
					// 	$('.processing-comments').css({'height':'75px'});
					// 	$('.processing-tips').css({'padding':'105px 105px 0 105px'});

					// 	if (userAgent.indexOf('chrome') == -1) {
					// 		//This is the Safari browser;  
					// 		$('.direct-buy-now').css({'padding':'2px 0px 0px 0px'});
					// 	}
					// 	else {
					// 		//This is the Chrome browser
					// 		$('.direct-buy-now').css({'padding':'0px 0px 0px 0px'});
					// 	}
					// 	$('.btnDirectBuyNow').css({'margin':'0px 0px 6px 0px'});
					// 	$('.btnDirectBuyNow').css({'padding':'3px 30px 3px 30px'});
					// 	$('.btnDirectBuyNow').css({'font-size':'20px'});

					// 	$('.personal-buy-now').css({'padding':'36px 0px 0px 0px'});
					// 	$('.btnPersonalBuyNow').css({'margin':'0px 0px 0px 0px'});
					// 	$('.btnPersonalBuyNow').css({'padding':'0px 30px 0px 30px'});
					// 	$('.btnPersonalBuyNow').css({'font-size':'20px'});

					// 	$('.startup-buy-now').css({'padding':'36px 0px 0px 0px'});
					// 	$('.btnStartupBuyNow').css({'margin':'0px 0px 0px 0px'});
					// 	$('.btnStartupBuyNow').css({'padding':'0px 30px 0px 30px'});
					// 	$('.btnStartupBuyNow').css({'font-size':'20px'});
					// } else if (item.languageCode === 'zh-CN') {
					// 	$('.direct-buy-now').css({'padding':'3px 50px 0px 50px'});
					// } else if (item.languageCode === 'de-DE') { 
					// 	$('.direct-buy-now').css({'padding':'6px 0px 0px 0px'});
					// 	$('.personal-buy-now').css({'padding':'36px 0px 0px 0px'});
					// 	$('.startup-buy-now').css({'padding':'36px 0px 0px 0px'});
					// }
				};

				var is_showing_other_input_errror = false;
				var btncontinue_activate = function (btnId, bActive) {
					jQuery(btnId).attr("disabled", !bActive);
				};

				// for buy now dialog
				var trialExpiryBuyNow_click = function () {
					context.selectedOption = 'Buy';
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.link);  //comment out for test

					//grant user 24hr local entitlements using registeredAsStudent when user clicks on "Buy Fusion 360" link
					//var appIdJson = {};
					//appIdJson.appId = item.appId;
					//window.neutronJavaScriptObject.executeQuery('registeredAsStudent', JSON.stringify(appIdJson));
					//window.neutronJavaScriptObject.executeQuery('refreshEntitlements', ''); 

					jQuery('#PurchaseProcessing').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#PurchaseProcessing').addClass("display_block");
				}

				jQuery('#btnBuyNow_0').click(function (event) {
					event.preventDefault();
					jQuery('#BuyFusionNow').hide();
					trialExpiryBuyNow_click();
					context.returnFlag = 'BuyFusionNow';
				});

				jQuery('#contactForHelp').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.hrefContactForHelp);
				});

				jQuery('#qualifyForFreeUse').click(function (event) {
					event.preventDefault();
					jQuery('#BuyFusionNow').hide();
					jQuery('#FreeUseOptoins').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#FreeUseOptoins').addClass("display_block");
				});

				jQuery('#hrefPricingOptions').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.hrefPricingOptions);
				});

				// PurchaseProcessing
				var clipboard = new Clipboard('.copy-button');
				clipboard.on('success', function (e) {
					console.log(e);
				});

				clipboard.on('error', function (e) {
					console.log(e);
				});

				var showNosubscriptionFound = function () {
					jQuery('#ValidateSubscription').hide();
					jQuery('#NoSubscriptionFound').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#NoSubscriptionFound').addClass("display_block");
				};

				var triggerDoValidateProcess = function () {
					context.isNeedingValidate = true;
					context.timeoutID = window.setTimeout(doValidateSubscription, 100);
				};

				jQuery('#finishedBuyContinue').click(function (event) {
					event.preventDefault();
					jQuery('#PurchaseProcessing').hide();
					jQuery('#ValidateSubscription').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#ValidateSubscription').addClass("display_block");
					triggerDoValidateProcess();
				});

				var buyReturnBackProcess = function (hideDivId) {
					if (context.returnFlag === 'BuyFusionNow') {
						context.returnFlag = '';
						jQuery(hideDivId).hide();
						jQuery('#BuyFusionNow').show();
						var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
						window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
						//jQuery('#BuyFusionNow').addClass("display_block");
					}
					else {
						jQuery(hideDivId).hide();
						jQuery('#FreeUseOptoins').show();
						var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
						window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
						//jQuery('#FreeUseOptoins').addClass("display_block");
					}
				};

				jQuery('#purchaseProcessBack').click(function (event) {
					event.preventDefault();
					buyReturnBackProcess('#PurchaseProcessing');
				});

				jQuery('#getHelpHere').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.helpBuyLink);
				});

				// ValidateSubscription
				var doValidateSubscription = function () {
					// adding the buy subscription check here
					if (context.isNeedingValidate === true) {
						context.isNeedingValidate = false;
						window.clearTimeout(context.timeoutID);

						window.neutronJavaScriptObject.executeQuery('refreshEntitlements', '');
						var argData = {};
						argData.appId = item.appId;
						window.neutronJavaScriptObject.executeQuery('EntitlementDetails', JSON.stringify(argData), function (retResponse) {
							var ent = JSON.parse(retResponse);
							if (ent.isnull === false) {
								if ((ent.trial === true) || (entitlement.enthusiast === true) || (ent.student === true) || (ent.entitled === false)) {
									showNosubscriptionFound();
								}
								else {
									context.licenseStatus = "SubscribeLicense";
									jQuery('#ValidateSubscription').hide();
									jQuery('#YouAreAllSet').show();
									jQuery('#accountAllSetDetail').html(neu.locStrings.buyAllSetDetail);
									var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
									window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
									jQuery('#YouAreAllSet').addClass("display_block");
								}
							}
							else {
								showNosubscriptionFound();
							}
						});
					}
				};

				// test purpose for exception or not buying check
				jQuery('#validateWaitBanner').click(function (event) {
					event.preventDefault();
					jQuery('#ValidateSubscription').hide();
					jQuery('#NoSubscriptionFound').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#NoSubscriptionFound').addClass("display_block");
				});

				// test purpose for all done
				jQuery('#validateBuyInfo').click(function (event) {
					event.preventDefault();
					jQuery('#ValidateSubscription').hide();
					jQuery('#YouAreAllSet').show();
					jQuery('#accountAllSetDetail').html(neu.locStrings.buyAllSetDetail);
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#YouAreAllSet').addClass("display_block");
				});

				// NoSubscriptionFound
				jQuery('#btnTryItAgain').click(function (event) {
					event.preventDefault();
					jQuery('#NoSubscriptionFound').hide();
					jQuery('#ValidateSubscription').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#ValidateSubscription').addClass("display_block");
					triggerDoValidateProcess();
				});

				jQuery('#buyProcessingBack').click(function (event) {
					event.preventDefault();
					buyReturnBackProcess('#NoSubscriptionFound');
				});

				// for free use options
				jQuery('#btnDirectBuyNow_0').click(function (event) {
					event.preventDefault();
					jQuery('#FreeUseOptoins').hide();
					trialExpiryBuyNow_click();
				});

				jQuery('#startupCompany').click(function (event) {
					context.selectedOption = 'Startup'; // for startup company option selection
					context.selectedOption = 'Startup'; // for startup company option selection
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.startupLink);
					// startup confirm dialog showing here
					jQuery('#StartupProcessing').show();
					jQuery('#StartupProcessing').addClass("display_block");
					jQuery('#FreeUseOptoins').hide();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
				});

				jQuery('#personalProjects').click(function (event) {
					context.selectedOption = 'Personal'; // for personal option selection
					jQuery('#FreeUseOptoins').hide();
					jQuery('#FreePersonalLicense').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#FreePersonalLicense').addClass("display_block");
				});

				jQuery('#eduStudent').click(function (event) {
					context.selectedOption = 'Education'; // for edu student option selection
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.fusionRegEduLink);
					// edu confirm dialog showing here
					jQuery('#FreeUseOptoins').hide();
					jQuery('#EduRegProcessing').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#EduRegProcessing').addClass("display_block");
				});

				jQuery('#startupReadLicenseTerms').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.startupCompanyTerms);
				});

				jQuery('#readmoreLicenseInfo').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.hrefReadLicense);
				});

				var personalLicenseSubmit = function (type, opt_queryCallback, opt_this) {
					window.neutronJavaScriptObject.executeQuery('personalLicenseSubmit', type, function (response) {
						opt_queryCallback.call(opt_this, JSON.parse(response));
						return;
					});
				}


				var sendTry2BuyOptions = function (opt_queryCallback, opt_this) {
					var args = {
						licenseStatus: context.licenseStatus,
						selectedOption: context.selectedOption
					};
					if (context.companyName != "") {
						args.companyName = context.companyName;
					}
					if (context.websiteName != "") {
						args.websiteName = context.websiteName;
					}
					window.neutronJavaScriptObject.executeQuery('sendSelectedOptions', JSON.stringify(args), function (retResponse) {
						opt_queryCallback.call(opt_this, JSON.parse(retResponse).success);
						return;
					});
				};

				var closeTryToBuyWindow = function (licenseStatus) {
					if (licenseStatus == "PersonalLicense") {
						window.neutronJavaScriptObject.executeQuery("changeLicenseStatus", "PersonalLicense");
						window.neutronJavaScriptObject.executeQuery('refreshEntitlements', '');
					}
					else if (licenseStatus == "StartupLicense") {
						window.neutronJavaScriptObject.executeQuery("changeLicenseStatus", "StartupLicense");
						window.neutronJavaScriptObject.executeQuery('refreshEntitlements', '');
					}
					else if (licenseStatus == "EduLicense") {
						window.neutronJavaScriptObject.executeQuery("changeLicenseStatus", "EduLicense");
					}
					else if (licenseStatus == "SubscribeLicense") {
						//window.neutronJavaScriptObject.executeQuery('refreshEntitlements', '');
					}

					sendTry2BuyOptions(function (_resp) {
						jQuery('#try2buyDialog').hide();
						window.open('', '_self', '');
						window.close();
						window.neutronJavaScriptObject.executeQuery("closeTryToBuyWidget", "");
					});
				};

				// for Personal
				var showPersonalTryAgain = function () {
					jQuery('#ValidatePersonalLicense').hide();
					jQuery('#FreePersonalTryAgain').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#FreePersonalTryAgain').addClass("display_block");
				};

				var triggerDoValidatePersonal = function () {
					context.isNeedingValidate = true;
					context.timeoutID = window.setTimeout(doValidatePersonalLicense, 100);
				};

				var doValidatePersonalLicense = function () {
					if (context.isNeedingValidate === true) {
						context.isNeedingValidate = false;
						window.clearTimeout(context.timeoutID);

						personalLicenseSubmit("personal", function (ret) {
							if (ret) {
								jQuery('#ValidatePersonalLicense').hide();
								jQuery('#YouAreAllSet').show();
								context.licenseStatus = "PersonalLicense";
								var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
								window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
								jQuery('#YouAreAllSet').addClass("display_block");
							}
							else { // error handling process
								showPersonalTryAgain();
							}
						});
					}

				};

				jQuery('#personalLicenseContinue').click(function (event) {
					event.preventDefault();
					jQuery('#FreePersonalLicense').hide();
					jQuery('#PersonalCompletePage').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
				});

				jQuery('#personalCompleteRegistration').click(function (event) {
					event.preventDefault();
					jQuery('#PersonalCompletePage').hide();
					jQuery('#ValidatePersonalLicense').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#ValidatePersonalLicense').addClass("display_block");
					triggerDoValidatePersonal();
				});

				jQuery('#btnPersonalBuyNow').click(function (event) {
					event.preventDefault();
					jQuery('#FreePersonalLicense').hide();
					trialExpiryBuyNow_click();
				});

				jQuery('#btnPersonalBuyNowComplete').click(function (event) {
					event.preventDefault();
					jQuery('#PersonalCompletePage').hide();
					trialExpiryBuyNow_click();
				});

				jQuery('#personlReadLicenseInfo').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.hrefReadLicense);
				});

				jQuery('#personlReadLicenseInfoComplete').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.hrefReadLicense);
				});

				var returnOptionsFromPersonalPages = function () {
					jQuery('#FreeUseOptoins').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					if (jQuery('#personalCheckOne').is(':checked')) {
						jQuery('#personalCheckOne').attr("checked", false);
					}
					if (jQuery('#personalCheckTwo').is(':checked')) {
						jQuery('#personalCheckTwo').attr("checked", false);
					}
					personalCheckbox_click();
				};

				jQuery('#personalReturnBack').click(function (event) {
					event.preventDefault();
					jQuery('#FreePersonalLicense').hide();
					returnOptionsFromPersonalPages();
				});

				jQuery('#personalReturnBackComplete').click(function (event) {
					event.preventDefault();
					jQuery('#PersonalCompletePage').hide();
					returnOptionsFromPersonalPages();
				});

				var personalCheckbox_click = function () {
					if (jQuery('#personalCheckOne').is(':checked') && jQuery('#personalCheckTwo').is(':checked')) {
						btncontinue_activate('#personalLicenseContinue', true);
					}
					else {
						btncontinue_activate('#personalLicenseContinue', false);
					}
				};

				jQuery('#personalCheckOne').click(function (event) {
					personalCheckbox_click();
				});

				jQuery('#personalCheckTwo').click(function (event) {
					personalCheckbox_click();
				});

				var test_count = 0;
				jQuery('#btnTryItAgainPersonal').click(function (event) {
					event.preventDefault();
					test_count++;
					jQuery('#FreePersonalTryAgain').hide();
					jQuery('#ValidatePersonalLicense').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#ValidatePersonalLicense').addClass("display_block");
					triggerDoValidatePersonal();
				});

				jQuery('#notFoundBackPersonal').click(function (event) {
					event.preventDefault();
					jQuery('#FreePersonalTryAgain').hide();
					jQuery('#FreeUseOptoins').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#FreeUseOptoins').addClass("display_block");
					// reset the data selection here
					if (jQuery('#personalCheckOne').is(':checked')) {
						jQuery('#personalCheckOne').attr("checked", false);
					}
					if (jQuery('#personalCheckTwo').is(':checked')) {
						jQuery('#personalCheckTwo').attr("checked", false);
					}
					personalCheckbox_click();
				});

				// NEW STARTUP WORKFLOW
				jQuery('#finishedStartupContinue').click(function (event) {
					event.preventDefault();
					jQuery('#StartupProcessing').hide();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					showWaitForStartupMessage();
				});

				jQuery('#startupProcessBack').click(function (event) {
					event.preventDefault();
					jQuery('#StartupProcessing').hide();
					jQuery('#FreeUseOptoins').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#FreeUseOptoins').addClass("display_block");
				});

				var showWaitForStartupMessage = function () {
					context.licenseStatus = "StartupLicense";
					jQuery('#accountAllSetInfo').html(neu.locStrings.accountThanksInfo);
					jQuery('#btnStartUsingFusion_0').val(neu.locStrings.gotIt)
					jQuery('#accountAllSetDetail').html(neu.locStrings.startupWaitDetail);
					jQuery('#YouAreAllSet').addClass("display_block");
					jQuery('#YouAreAllSet').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#YouAreAllSet').addClass("display_block");
				};

				// test purpose for exception or not buying check
				jQuery('#validateWaitBannerStartup').click(function (event) {
					event.preventDefault();
					jQuery('#ValidateStartupRegister').hide();
					jQuery('#NoStartupRegisterFound').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#NoStartupRegisterFound').addClass("display_block");
				});

				// test purpose for all done
				jQuery('#validateEduInfo').click(function (event) {
					event.preventDefault();
					jQuery('#ValidateStartupRegister').hide();
					jQuery('#YouAreAllSet').show();
					jQuery('#accountAllSetDetail').html(neu.locStrings.startupAllSetDetail);
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#YouAreAllSet').addClass("display_block");
				});

				jQuery('#notFoundBackStartup').click(function (event) {
					event.preventDefault();
					jQuery('#NoStartupRegisterFound').hide();
					jQuery('#StartupProcessing').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#StartupProcessing').addClass("display_block");
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.startupLink);
				});

				jQuery('#getHelpHereStartup').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.helpLink);
				});

				// for EduRegProcessing
				var showNoEduRegistrationFound = function () {
					jQuery('#ValidateEduRegister').hide();
					jQuery('#NoEduRegisterFound').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#NoEduRegisterFound').addClass("display_block");
				};

				var triggerEduRegValidate = function () {
					context.isNeedingValidate = true;
					context.timeoutID = window.setTimeout(doValidateEduRegister, 100);
				};

				jQuery('#finishedEduContinue').click(function (event) {
					event.preventDefault();
					jQuery('#EduRegProcessing').hide();
					jQuery('#ValidateEduRegister').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#ValidateEduRegister').addClass("display_block");
					triggerEduRegValidate();
				});

				jQuery('#eduRegProcessBack').click(function (event) {
					event.preventDefault();
					jQuery('#EduRegProcessing').hide();
					jQuery('#FreeUseOptoins').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#FreeUseOptoins').addClass("display_block");
				});

				var doValidateEduRegister = function () {
					if (context.isNeedingValidate === true) {
						context.isNeedingValidate = false;//edit
						window.clearTimeout(context.timeoutID);

						window.neutronJavaScriptObject.executeQuery('refreshEntitlements', '');
						var argData = {};
						argData.appId = item.appId;
						window.neutronJavaScriptObject.executeQuery('EntitlementDetails', JSON.stringify(argData), function (ret) {
							var ent = JSON.parse(ret);
							if (ent.isnull === false) {
								if ((ent.student === false) || (ent.entitled === false)) {
									showNoEduRegistrationFound();
								}
								else {
									context.licenseStatus = "EduLicense";
									jQuery('#ValidateEduRegister').hide();
									jQuery('#YouAreAllSet').show();
									jQuery('#accountAllSetDetail').html(neu.locStrings.eduRegAllSetDetail);
									var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
									window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
									jQuery('#YouAreAllSet').addClass("display_block");
								}
							}
							else {
								showNoEduRegistrationFound();
							}
						});
					}
				};


				// test purpose for exception or not buying check
				jQuery('#validateWaitBannerEdu').click(function (event) {
					event.preventDefault();
					jQuery('#ValidateEduRegister').hide();
					jQuery('#NoEduRegisterFound').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#NoEduRegisterFound').addClass("display_block");
				});

				// test purpose for all done
				jQuery('#validateEduInfo').click(function (event) {
					event.preventDefault();
					jQuery('#ValidateEduRegister').hide();
					jQuery('#YouAreAllSet').show();
					jQuery('#accountAllSetDetail').html(neu.locStrings.eduRegAllSetDetail);
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#YouAreAllSet').addClass("display_block");
				});

				// NoEduRegisterFound
				jQuery('#btnTryItAgainEdu').click(function (event) {
					event.preventDefault();
					jQuery('#NoEduRegisterFound').hide();
					jQuery('#ValidateEduRegister').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#ValidateEduRegister').addClass("display_block");
					triggerEduRegValidate();
				});

				jQuery('#notFoundBackEdu').click(function (event) {
					event.preventDefault();
					jQuery('#NoEduRegisterFound').hide();
					jQuery('#EduRegProcessing').show();
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
					jQuery('#EduRegProcessing').addClass("display_block");
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.fusionRegEduLink);
				});

				jQuery('#getHelpHereEdu').click(function (event) {
					event.preventDefault();
					window.neutronJavaScriptObject.executeQuery("linkClicked", item.helpLink);
				});

				// for YouAreAllSet
				jQuery('#btnStartUsingFusion_0').click(function (event) {
					event.preventDefault();
					closeTryToBuyWindow(context.licenseStatus);
				});

				jQuery('.trialExpiryClose').click(function (event) {
					event.preventDefault();
					closeTryToBuyWindow(context.licenseStatus);
				});

				jQuery('.confirmationClose').click(function (event) {  // not used now
					event.preventDefault();
					closeTryToBuyWindow(context.licenseStatus);
				});

				jQuery('.trialexpiry-close-icon').click(function (event) {
					event.preventDefault();
					closeTryToBuyWindow(context.licenseStatus);
				});

				jQuery('#divLoading').hide();
				jQuery('#BuyFusionNow').addClass("display_block");
				jQuery('#BuyFusionNow').removeClass("default-nodisplay");
				jQuery('#BuyFusionNow').addClass("display_block");
				jQuery('#BuyFusionNow').show();
				jQuery('#try2buyDialog').removeClass("default-nodisplay");
				jQuery('#try2buyDialog').addClass("display_block");
				jQuery('#try2buyDialog').show();

				//I found the layout of HTML pages could be different between Chrome and Safari
				//even the same CSS styles are appplied; this could be due to the different 
				//rendering of the same fonts between Windows and Mac
				//To fix this, we need to apply different padding-bottom style on different browsers
				var firstPageHeight = '456';
				if (userAgent.indexOf('chrome') == -1) {
					//This is the Safari browser;  
					jQuery('#try2buyDialog').addClass("try2buyDialog-safari-collapse");
				}
				else {
					//This is the Chrome browser
					jQuery('#try2buyDialog').addClass("try2buyDialog-chrome");
				}
				// hardcoded correct size
				window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", firstPageHeight);
				// Also resize to the computed height after it gets a chance to render for future proofing
				window.setTimeout(() => {
					var divHeight = String(document.getElementById('try2buyDialog').offsetHeight);
					window.neutronJavaScriptObject.executeQuery("resizeTryToBuyWindow", divHeight);
				}, 0);
				//});
			});
		});
	}
}

IPM.bootStrap();
